<?php
/**
 * Created by PhpStorm.
 * User: Shubham
 * Date: 6/23/2016
 * Time: 1:35 PM
 */

//start the session to get session variables
session_start();

//store the session array into variables
extract($_SESSION);

//unset the session variables
session_unset();

//get  connect to database
require "databaseconnection.php";

//build the sql
$sql = "SELECT id, artist_name FROM tblArtist";

//prepare the sql statement
$sth = $dbh->prepare($sql);

//execute the sql statement
$sth->execute();

//store all the rows from database into artist
$Artist = $sth->fetchAll();

//store all the row count from database into row_count
$row_count = $sth->rowCount();

//set the database connection to null, to end the connection
$dbh = null;

?>
<!DOCTYPE HTML>
<html lang="en">
<!--head region of the page-->
<head>
    <meta name="viewport" content="width=device-width initial-scale=1">
    <!--link to stylesheets-->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
          crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-aNUYGqSUL9wG/vP7+cWZ5QOM4gsQou3sBfWRr/8S3R1Lv0rysEmnwsRKMbhiQX/O"
          crossorigin="anonymous">
    <link href="stylesheets/common.css" rel="stylesheet">
    <!--title of the page-->
    <title>New Artist</title>
</head>
<body>
<div class="container">
   
    <!--include the navbar to get header of the page-->
    <?php include "navbar.php" ?>
    <!--if there is any artist stored then allow the user to add new movies-->
    <?php if ($row_count > 0): ?>
        <!--if there is any error after the validation of the form it goes here-->
        <?php if (isset($errorMovies)): ?>
            <div class="alert alert-danger">
                <?= $errorMovies; ?>
            </div>
        <?php endif; ?>
        <div>
            <!--heading of the page-->
            <h1>Please provide the information below to add a new movie to the list</h1>
        </div>
        <!--input form for the page-->
        <form class="form-horizontal" method="post" action="add_movies.php">
            <fieldset>
                <legend>Movie Information</legend>
                <div class="form-group <?php if (isset($errartist_id)): echo "has-error has-feedback"; endif; ?>">
                    <label class="col-sm-2 control-label" for="artist_id">artist</label>
                    <div class="input-group">
                        <select name="artist_id" class="form-control col-sm-3 col-sm-offset-1" required>
                            <option value="selectartist" selected>----Select Artist----</option>
                            <?php foreach ($Artist as $Artist) : ?>
                                <option value="<?= $Artist["id"] ?>"
                                    <?php if (isset($artist_id) && $Artist["id"] == $artist_id): ?>
                                        <?= "selected"; ?>
                                    <?php endif; ?>>
                                    <?= $Artist["artist_name"] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!--if the error is in the selection of artist then it goes here-->
                    <?php if (isset($errartist_id)): ?>
                        <div class="text-danger"><?= $errartist_id ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php if (isset($errMoviesName)): echo "has-error has-feedback"; endif; ?>">
                    <label class="col-sm-2 control-label" for="movie name">Movie Name</label>
                    <div class="col-sm-4">
                        <input class="form-control input-sm" type="text" name="movie_name" max="15" required
                               pattern="[A-Za-z]{3,15}" placeholder="Movie name"
                               title="Please provide correct movie name"
                            <?php if (isset($movie_name)): echo "value=" . $movie_name; endif; ?>>
                    </div>
                    <div  class="col-sm-4">
                        <input class="form-control input-sm" type="text" name="Movie_rating" max="15" required
                                placeholder="Movies rating"
                               title="Please provide the ratings to the movie"
                            <?php if (isset($Movie_rating)): echo "value=" . $Movie_rating; endif; ?>>
                    </div>
                    <!--if the error is in the input of movie name then it goes here-->
                    <?php if (isset($errMovie_rating)): ?>
                        <div class="text-danger"><?= $errMovie_rating ?></div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="movie_director">Movie Director</label>
                    <div class="col-sm-4">
                        <input class="form-control input-sm" type="text" name="movie_director" max="15"
                               pattern="[1-3A-Za-z\s]{3,15}" placeholder="movie director"
                               title="Please provide correct movie director"
                            <?php if (isset($movie_director)): echo "value=" . $movie_director; endif; ?>>
                    </div>
                </div>

                <div class="input-group col-sm-offset-2">
                    <button class="btn btn-primary"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Movie</button>
                </div>
            </fieldset>
        </form>
    <?php else: ?>
        <div class="alert alert-warning">
            <p>No artist found.<a href="new_artist.php.php">&nbsp;&nbsp;Add Artist</a></p>
        </div>
    <?php endif; ?>
</div>
<script src="https://code.jquery.com/jquery-2.2.3.min.js"
        integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
        integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
        crossorigin="anonymous"></script>
</body>
</html>