USE gc200333595;
create  TABLE tblArtist(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist_name` varchar(100) NOT NULL,
  `date_of_birth` date  NOT NULL,
  `country` varchar(15) null,
  PRIMARY KEY (`id`)
  ); 
  

CREATE TABLE tblMovies (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `artist_id` int (11) not null,
  `movie_name` varchar(100) not null,
  `Movie_rating` decimal(10,2) NOT NULL,
  `movie_director` varchar(40) not null,
 PRIMARY KEY (`id`),
     FOREIGN KEY (`artist_id`) REFERENCES tblArtist(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ;

select * from tblArtist;