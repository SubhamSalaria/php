<?php

session_start();
//store the post array into variables
extract($_POST);



//set the validation to true
$validated = true;

//validate and sanitize the artist name
if (empty($artist_name)) {
    $_SESSION["errArtist_name"] = "Please enter the correct artist name";
    $validated = false;
} else {
    $artist_name = filter_var($artist_name, FILTER_SANITIZE_STRING);
}

//validate and sanitize the dob
if (empty($date_of_birth)) {
    $_SESSION["errDateOfBirth"] = "Please enter the correct Date of birth";
    $validated = false;

}

//sanitize the artist country
if (!empty($country)) {
    $country = filter_var($country, FILTER_SANITIZE_STRING);
}

//if there is any error redirect to form page and show the errors and populate the user's data
if ($validated == false) {
    $_SESSION["errorArtist"] = "Artist could not be added due to the following error(s)";
    $_SESSION = array_merge($_SESSION, $_POST);
    header("Location: new_artist.php");
} else {
    //connect to database
    require "databaseconnection.php";

    //build the sql
    $sql = "INSERT INTO tblArtist(artist_name, date_of_birth, country) VALUES (:artist_name, :date_of_birth, :country)";

    //prepare the sql statement
    $sth = $dbh->prepare($sql);

    //bind parameters
    $sth->bindParam(':artist_name', $artist_name, PDO::PARAM_STR,100 );
    $sth->bindParam(':date_of_birth', $date_of_birth);
    $sth->bindParam(':country', $country, PDO::PARAM_STR, 15);

    //execute the sql statement
    $sth->execute();

    //set the database connection to null, to end the connection
    $dbh = null;

    //redirect to the artist page
    header("Location: artist.php");
}