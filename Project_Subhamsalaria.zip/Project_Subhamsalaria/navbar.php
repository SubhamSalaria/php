<!--/**
 * Created by PhpStorm.
 * User: Shubham
 * Date: 6/23/2016
 * Time: 4:37 PM
 */-->


<header>
    <div>
        <nav>
            <ul class="nav nav-pills">
                <li role="presentation"><a href="main.php">Home</a></li>
                <li role="presentation"><a href="new_artist.php">New Artist</a></li>
                <li role="presentation"><a href="new_movies.php">New Movies</a></li>
                <li role="presentation"><a href="artist.php">View Artist</a></li>
                <li role="presentation" class="navbar-tab navbar-right">
                  
           </li>
            </ul>
        </nav>
    </div>
</header>