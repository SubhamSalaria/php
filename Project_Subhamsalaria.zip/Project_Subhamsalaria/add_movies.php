<?php

session_start();


//store the post array into variables
extract($_POST);



//set the validation to true
$validated = true;

//validate and sanitize the artist_id
if ($artist_id == "selectartist") {
    $_SESSION["errArtist_id"] = "Please select a Artist";
    $validated = false;
} else {
    $artist_id = filter_var($artist_id, FILTER_SANITIZE_NUMBER_INT);
}

//validate and sanitize the movie_name
if (empty($movie_name)) {
    $_SESSION["errMovie_name"] = "Please enter the correct Movie name";
    $validated = false;
} else {
    $movie_name = filter_var($movie_name, FILTER_SANITIZE_STRING);

}

//sanitize the movie rating
if (!empty($Movie_rating)) {
    $Movie_rating = filter_var($Movie_rating, FILTER_SANITIZE_NUMBER_FLOAT);
}

//sanitize the movie director
if (!empty($movie_director)) {
    $movie_director = filter_var($movie_director, FILTER_SANITIZE_STRING);
}

//if there is any error redirect to form page and show the errors and populate the user's data
if ($validated == false) {
    $_SESSION["errorMovie"] = "Movie could not be added due to following error(s)";
    $_SESSION = array_merge($_SESSION, $_POST);
    header("Location: new_movies.php");
} else {
    // connect to database
    require "databaseconnection.php";

    //build the sql
    $sql = "INSERT INTO tblMovies(artist_id,movie_name, Movie_rating , movie_director)
 VALUES (:artist_id,:movie_name,:Movie_rating,:movie_director)";

    //prepare the sql statement
    $sth = $dbh->prepare($sql);
  $Movie_rating1 = floatval($Movie_rating);
    //bind parameters
    $sth->bindParam(':artist_id', $artist_id, PDO::PARAM_INT,11 );
    $sth->bindParam(':movie_name', $movie_name, PDO::PARAM_STR,100 );
    $sth->bindParam(':Movie_rating', $Movie_rating1);
    $sth->bindParam(':movie_director', $movie_director, PDO::PARAM_STR, 40);


    //execute the sql statement
     $sth->execute();

    //set the database connection to null, to end the connection
    $dbh = null;

    //redirect to movie page to show the added artist
    header("Location:movies.php?artist_id=$artist_id");
}