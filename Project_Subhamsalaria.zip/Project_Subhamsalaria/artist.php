
<?php

/**
 * Created by PhpStorm.
 * User: Shubham
 * Date: 6/23/2016
 * Time: 4:14 PM
 */

//get  connect to database
require "databaseconnection.php";

//build the sql
$sql = "SELECT * FROM tblArtist";

//prepare the sql statement
$sth = $dbh->prepare($sql);

//execute the sql statement
$sth->execute();

//store all the rows from database into artist
$Artist = $sth->fetchAll();

//store all the row count from database into row_count
$row_count = $sth->rowCount();

//set the database connection to null, to end the connection
$dbh = null;
?>
<!DOCTYPE HTML>
<html lang="en">
<!--head region of the page-->
<head>
    <!--link to stylesheets-->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-aNUYGqSUL9wG/vP7+cWZ5QOM4gsQou3sBfWRr/8S3R1Lv0rysEmnwsRKMbhiQX/O" crossorigin="anonymous">
    <link href="stylesheets/common.css" rel="stylesheet">
    <!--title of the page-->
    <title>Artist</title>
</head>
<body>
<div class="container">
  
    <!--include the navbar to of the page-->
    <?php include "navbar.php" ?>
    <!--if there is any error after the validation of the form it goes here-->
    <section>
      
        <?php if ($row_count > 0): ?>
            <div>
                <!--heading of the page-->
                <h1>Artist</h1>
            </div>
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Artist name</th>
                    <th>Date of Birth</th>
                    <th>Artist Country</th>
                </tr>
                </thead>
                <tbody>
                <?php $number = 1 ?>
                <?php foreach ($Artist as $Artist): ?>
                    <tr>
                        <td><?= $number ?></td>
                        <td>
                            <a href="movies.php?artist_id=<?= $Artist["id"] ?>"><?= $Artist["artist_name"] ?></a>
                        </td>
                        <td><?= $Artist["date_of_birth"] ?></td>
                        <td><?= $Artist["country"] ?></td>

                        <?php $number++ ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <!--if there was no artist then give the warning to the user-->
            <div class="alert alert-warning">
                <p>No artist found.<a href="new_artist.php">&nbsp;&nbsp;Add Artist</a></p>
            </div>
        <?php endif ?>
    </section>
</div>
<script src="https://code.jquery.com/jquery-2.2.3.min.js"
        integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
        integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
        crossorigin="anonymous"></script>
</body>
</html>